import { Component, OnInit } from '@angular/core';
// import { FormControl, FormGroup } from '@angular/forms';
import {FormBuilder,FormGroup,FormControl,Validators,NgForm} from '@angular/forms' 

@Component({
  selector: 'app-reactive-forms',
  templateUrl: './reactive-forms.component.html',
  styleUrls: ['./reactive-forms.component.css']
})
export class ReactiveFormsComponent implements OnInit {
  signupForm:FormGroup;  

  FirstName:string="";  
  
  LastName:string="";  
  
  Email:string="";  
  
  Password:string="";  
  
  constructor(private frmbuilder:FormBuilder)  
  
     {  
  
      this.signupForm=frmbuilder.group({  
  
      fname:new FormControl(),  
  
      lname:new FormControl(),  
  
      Emailid:new FormControl(),  
  
      userpassword:new FormControl()  
  
      });  

      this.signupForm= frmbuilder.group({  

        fname:['',Validators.compose([Validators.required,Validators.maxLength(15),Validators.minLength(1)])],  
      
        lname:['',[Validators.required,Validators.maxLength(19)]],  
      
        Emailid:['',[Validators.required,Validators.email]],  
      
        userpassword:['',Validators.required]  
      
      })
  
     }  

     
  
    ngOnInit() {  
  
    }  
  
    PostData(signupForm:NgForm)  
  
    {  
  
      console.log(signupForm.controls.Emailid.value);  
  
    }  
  
  }